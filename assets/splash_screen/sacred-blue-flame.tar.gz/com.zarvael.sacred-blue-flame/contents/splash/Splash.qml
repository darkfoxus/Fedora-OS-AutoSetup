import QtQuick
import QtMultimedia

Rectangle {
    id: root
    color: "black"

    // Set by KDE during login; not used here
    property int stage

    MediaPlayer {
        id: player
        source: Qt.resolvedUrl("images/video.webm")
        videoOutput: video
        loops: MediaPlayer.Infinite
        Component.onCompleted: play()
    }

    VideoOutput {
        id: video
        anchors.fill: parent
        fillMode: VideoOutput.PreserveAspectCrop
    }
}
